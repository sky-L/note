<?php
require 'RedisPool.php';
$conf=array(
'FA'=>array('127.0.0.1',6379)
);
RedisPool::addServer($conf);
$redis= RedisPool::getRedis('FA');
$list=$redis->lrange("list:users",0,-1);
for($i=0;i<count($list);$i++){
    echo $list[$i]."<br>";
}
?>
