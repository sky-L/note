<?php
require 'RedisPool.php';
if(isset($_POST["username"])){

    $conf=array(
    'FA'=>array('127.0.0.1',6379)
    );

    RedisPool::addServer($conf);
    $redis= RedisPool::getRedis('FA');
    $username=$_POST["username"];
    $password=$_POST["password"];
    $redis->set("string:user:".$username,$password);
    
    $redis->rpush("list:users",$username);
}


?>
<html>
<head></head>
<body>
<form action="" method="post">
username:<input name="username" /><br>
password:<input name="password" /><br>
<input type="submit" />
</form>
</body>
</html>
